# Selam Gençler
Sizler İçin Yaptığım Kısa ve Öz Sözlerim Sitesi.
